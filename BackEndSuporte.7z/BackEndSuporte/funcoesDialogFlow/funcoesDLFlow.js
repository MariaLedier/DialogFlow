import Servico from "../Persistencia/servicoDAO.js"

// --------- CARD PARA DIALOGF -----------
export function criarMessengerCard() {
    return {
        type: "info",
        title: "",
        subtitle: "",
        image: {
            src: {
                rawUrl: ""
            }
        },
        actionLink: ""
    };
} 

// -------- FUNÇÃO PARA GERAR LISTA DE SERVIÇOS COMO CARDS ----------
export async function obterCardServicos(tipoCard = 'custom') {
    const servicoModelo = new Servico();
    const listaServicos = await servicoModelo.consultarTodos();
    const listaCards = [];

    // -------- add o titulo independente fixo ----------
    
        listaCards.push({
            type: "info",
            title: "Consultar",
            subtitle: "",
            image: {
                src: { rawUrl: "https://cdn-icons-png.flaticon.com/512/190/190411.png" }
            },
            actionLink: ""
        });


    // -------- Cards de serviço ----------
    for (const servico of listaServicos) {
        let cartao;

            cartao = criarMessengerCard();
            cartao.title = servico.nome;
            cartao.image.src.rawUrl = "https://cdn-icons-png.flaticon.com/512/190/190411.png";
        

        listaCards.push(cartao);
       
    }

    return listaCards;
}
