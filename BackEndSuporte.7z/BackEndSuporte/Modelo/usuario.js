import UsuarioDAO from "../Persistencia/usuarioDAO.js";

export default class Usuario {
    #id;
    #nome;
    #matricula;
    #endereco;
    #telefone;

    constructor(id = 0, nome = "", matricula = "", endereco = "", telefone = "") {
        this.#id = id;
        this.#nome = nome;
        this.#matricula = matricula;
        this.#endereco = endereco;
        this.#telefone = telefone;
    }

    get id() { return this.#id; }
    get nome() { return this.#nome; }
    get matricula() { return this.#matricula; }
    get endereco() { return this.#endereco; }
    get telefone() { return this.#telefone; }

    set id(novoId) { this.#id = novoId; }
    set nome(novoNome) { this.#nome = novoNome; }
    set matricula(novaMatricula) { this.#matricula = novaMatricula; }
    set endereco(novoEndereco) { this.#endereco = novoEndereco; }
    set telefone(novoTelefone) { this.#telefone = novoTelefone; }

    toJSON() {
        return {
            id: this.#id,
            nome: this.#nome,
            matricula: this.#matricula,
            endereco: this.#endereco,
            telefone: this.#telefone
        };
    }

    async gravar() {
    const dao = new UsuarioDAO();
    await dao.gravar(this);
    return this.#id; // retorna o id gerado
}

    // async consultarPorMatricula(matricula) {
    //     const dao = new UsuarioDAO();
    //     const usuarioEncontrado = await dao.consultarPorMatricula(matricula);

    //     if (usuarioEncontrado) {
    //         this.#id = usuarioEncontrado.id;
    //         this.#nome = usuarioEncontrado.nome;
    //         this.#matricula = usuarioEncontrado.matricula;
    //         this.#endereco = usuarioEncontrado.endereco;
    //         this.#telefone = usuarioEncontrado.telefone;
    //         return this;
    //     } else {
    //         return null;
    //     }
    // }
}
