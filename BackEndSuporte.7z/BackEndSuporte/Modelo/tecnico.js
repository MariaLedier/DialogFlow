import TecnicoDAO from "../Persistencia/tecnicoDAO.js";

export default class Tecnico {
    #id;
    #nome;

    constructor(id = 0, nome = "") {
        this.#id = id;
        this.#nome = nome;
    }

    get id() {
        return this.#id;
    }

    set id(novoId) {
        this.#id = novoId;
    }

    get nome() {
        return this.#nome;
    }

    set nome(novoNome) {
        this.#nome = novoNome;
    }

    toJSON() {
        return {
            id: this.#id,
            nome: this.#nome
        };
    }

    async sortearTecnico() {
    const tecnicoDAO = new TecnicoDAO();
    const resultado = await tecnicoDAO.sortearTecnico();

    if (resultado) {
        this.#id = resultado.id;
        this.#nome = resultado.nome;
        return resultado;
    } else {
        return null;
    }
}

}
