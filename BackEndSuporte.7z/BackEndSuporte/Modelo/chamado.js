import ChamadoDAO from "../Persistencia/chamadoDAO.js";

export default class Chamado {
    #id;
    #usuario_id;
    #servico_id;
    #tecnico_id;
    #status;
    #data_abertura;

    constructor(id = 0, usuario_id = 0, servico_id = 0, tecnico_id = 0, status = "Em atendimento", data_abertura = "") {
        this.#id = id;
        this.#usuario_id = usuario_id;
        this.#servico_id = servico_id;
        this.#tecnico_id = tecnico_id;
        this.#status = status;
        this.#data_abertura = data_abertura;
    }

    get id() {
        return this.#id;
    }

    set id(novoId) {
        this.#id = novoId;
    }

    get usuario_id() {
        return this.#usuario_id;
    }

    set usuario_id(novoUsuarioId) {
        this.#usuario_id = novoUsuarioId;
    }

    get servico_id() {
        return this.#servico_id;
    }

    set servico_id(novoServicoId) {
        this.#servico_id = novoServicoId;
    }

    get tecnico_id() {
        return this.#tecnico_id;
    }

    set tecnico_id(novoTecnicoId) {
        this.#tecnico_id = novoTecnicoId;
    }

    get status() {
        return this.#status;
    }

    set status(novoStatus) {
        this.#status = novoStatus;
    }

    get data_abertura() {
        return this.#data_abertura;
    }

    set data_abertura(novaData) {
        this.#data_abertura = novaData;
    }

    toJSON() {
        return {
            id: this.#id,
            usuario_id: this.#usuario_id,
            servico_id: this.#servico_id,
            tecnico_id: this.#tecnico_id,
            status: this.#status,
            data_abertura: this.#data_abertura
        };
    }

    async gravar() {
        const chamadoDAO = new ChamadoDAO();
        await chamadoDAO.gravar(this);
        return this.id; // return o id
    }


   async consultarPorId(id) {
    const chamadoDAO = new ChamadoDAO();
    const resultado = await chamadoDAO.consultarPorId(id);
    return resultado; 
}
}
