import ServicoDAO from "../Persistencia/servicoDAO.js";

export default class Servico {
    #id;
    #nome;
    #prazo;

    constructor(id = 0, nome = "", prazo = "") {
        this.#id = id;
        this.#nome = nome;
        this.#prazo = prazo;
    }

    get id() {
        return this.#id;
    }

    get nome() {
        return this.#nome;
    }

    get prazo() {
        return this.#prazo;
    }

    set id(novoId) {
        this.#id = novoId;
    }

    set nome(novoNome) {
        this.#nome = novoNome;
    }

    set prazo(novoPrazo) {
        this.#prazo = novoPrazo;
    }

    async consultarPorNome(nome) {
        const dao = new ServicoDAO();
        const resultado = await dao.consultarPorNome(nome);

        if (resultado) {
            this.#id = resultado.id;
            this.#nome = resultado.nome;
            this.#prazo = resultado.prazo;
            return resultado;
        } else {
            return null;
        }
    }

    async consultarTodos() {
    const dao = new ServicoDAO();
    return await dao.consultarTodos();
}

}
