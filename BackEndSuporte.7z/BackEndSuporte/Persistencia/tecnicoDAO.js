import conectar from "./conexao.js";

export default class TecnicoDAO {
    async sortearTecnico() {
        const sql = "SELECT * FROM tecnicos ORDER BY RAND() LIMIT 1";
        const conexao = await conectar();

        try {
            const [linhas] = await conexao.query(sql); 
            return linhas[0];
        } catch (erro) {
            throw new Error(`Erro ao sortear técnico: ${erro.message}`);
        } finally {
            conexao.release();
        }
    }
}
