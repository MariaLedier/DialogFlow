import conectar from "./conexao.js";
import Usuario from "../Modelo/usuario.js";

export default class UsuarioDAO {
    async gravar(usuario) {
        const conexao = await conectar();

        try {
            if (usuario.id === 0) {
                const sql = "INSERT INTO usuarios (nome, matricula, endereco, telefone) VALUES (?, ?, ?, ?)";
                const valores = [usuario.nome, usuario.matricula, usuario.endereco, usuario.telefone];
                const [resultado] = await conexao.query(sql, valores);
                usuario.id = resultado.insertId;
                return usuario.id;
            } else {
                const sql = "UPDATE usuarios SET nome = ?, matricula = ?, endereco = ?, telefone = ? WHERE id = ?";
                const valores = [usuario.nome, usuario.matricula, usuario.endereco, usuario.telefone, usuario.id];
                await conexao.query(sql, valores);
                return usuario.id;
            }
        } catch (erro) {
            throw new Error(`Erro ao gravar usuário: ${erro.message}`);
        } finally {
            conexao.release();
        }
    }


    async consultarPorMatricula(matricula) {
        const conexao = await conectar();

        try {
            const sql = "SELECT * FROM usuarios WHERE matricula = ?";
            const [linhas] = await conexao.query(sql, [matricula]);

            if (linhas.length > 0) {
                const row = linhas[0];
                return new Usuario(row.id, row.nome, row.matricula, row.endereco, row.telefone);
            } else {
                return null;
            }
        } catch (erro) {
            throw new Error(`Erro ao consultar usuário: ${erro.message}`);
        } finally {//SEMPRE IRA ACONTECER INDEPENDENTE -> Mesmo que ocorra um erro, o FINALY garante que a CONEXAO SERA fechada
            conexao.release();
        }
    }
}
