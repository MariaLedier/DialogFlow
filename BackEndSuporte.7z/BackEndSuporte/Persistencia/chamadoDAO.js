import conectar from "./conexao.js";

export default class ChamadoDAO {
    async gravar(chamado) {
        const sql = "INSERT INTO chamados (usuario_id, servico_id, tecnico_id, status, data_abertura) VALUES (?, ?, ?, ?, ?)";
        const valores = [chamado.usuario_id, chamado.servico_id, chamado.tecnico_id, chamado.status, chamado.data_abertura];


        const conexao = await conectar(); 

        try {
            const [resultado] = await conexao.query(sql, valores); 
            chamado.id = resultado.insertId;
        } catch (erro) {
            throw new Error("Erro ao gravar chamado: " + erro.message);
        } finally {
            conexao.release();
        }
    }

    async consultarPorId(id) {
        const sql = `
            SELECT c.id, c.status, c.data_abertura, 
                   u.nome AS nome_usuario, 
                   s.nome AS servico, 
                   t.nome AS tecnico
            FROM chamados c
            JOIN usuarios u ON c.usuario_id = u.id
            JOIN servicos s ON c.servico_id = s.id
            JOIN tecnicos t ON c.tecnico_id = t.id
            WHERE c.id = ?
        `;

        const conexao = await conectar();

        try {
            const [linhas] = await conexao.query(sql, [id]);
            return linhas[0];
        } catch (erro) {
            throw new Error("Erro ao consultar chamado: " + erro.message);
        } finally {
            conexao.release();
        }
    }
}
