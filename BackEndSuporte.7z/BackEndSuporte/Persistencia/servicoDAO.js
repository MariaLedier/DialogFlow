import conectar from './conexao.js';

export default class ServicoDAO {
    async consultarPorNome(nome) {
        const sql = 'SELECT id, nome, prazo_atendimento FROM servicos WHERE nome = ?';
        const conexao = await conectar();

        try {
            const [rows] = await conexao.query(sql, [nome]);

            if (rows.length > 0) {
                return {
                    id: rows[0].id,
                    nome: rows[0].nome,
                    prazo: rows[0].prazo_atendimento
                };
            } else {
                return null;
            }
        } catch (erro) {
            throw new Error(`Erro ao consultar serviço: ${erro.message}`);
        } finally {
            conexao.release();
        }
    }

    async consultarTodos() {
        const sql = 'SELECT id, nome, prazo_atendimento FROM servicos';
        const conexao = await conectar();

        try {
            const [rows] = await conexao.query(sql);

            return rows.map(row => ({
                id: row.id,
                nome: row.nome,
                prazo: row.prazo_atendimento
            }));
        } catch (erro) {
            throw new Error(`Erro ao consultar serviços: ${erro.message}`);
        } finally {
            conexao.release();
        }
    }
}
