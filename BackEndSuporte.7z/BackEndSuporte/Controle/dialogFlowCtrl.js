import { obterCardServicos } from "../funcoesDialogFlow/funcoesDLFlow.js";
import Usuario from "../Modelo/usuario.js";
import Chamado from "../Modelo/chamado.js";
import Tecnico from "../Modelo/tecnico.js";
import Servico from "../Modelo/servico.js";

export default class DialogFlowCtrl {

    async processarIntencoes(req, res) {
        if (req.method === 'POST') {
            const intencao = req.body.queryResult.intent.displayName;
            const origem = req.body?.originalDetectIntentRequest?.source;

            // ------- MENSAGEM DE BOAS VINDAS APRESENTAÇÃO DO MENU --------
            if (intencao === 'BoasVindas') {
                const tipo = origem ? 'custom' : 'messenger';

                try {
                    const listaCards = await obterCardServicos(tipo);
                    const respostaDF = { fulfillmentMessages: [] };

                        respostaDF.fulfillmentMessages.push({
                            payload: {
                                richContent: [[
                                    {
                                        type: "description",
                                        title: "Olá! Seja bem-vindo!",
                                        text: ["Confira nossos serviços disponíveis:"]
                                    },
                                    ...listaCards,
                                    {
                                        type: "description",
                                        title: "Você pode perguntar também sobre Horários de funcionamento, Atendimento e Localização",
                                        text: ["Como podemos te ajudar hoje?"]
                                    }
                                ]]
                            }
                        });
                    

                    res.json(respostaDF);

                } catch (erro) {
                    res.json({
                        fulfillmentMessages: [{
                            text: {
                                text: ["Erro ao recuperar os serviços. Por favor, tente novamente mais tarde."]
                            }
                        }]
                    });
                }
            }

            //---------------FUNÇÕES ADICIONAIS---------------------
            else if (intencao === 'HorarioFuncionamento') {
                return res.json({
                    fulfillmentMessages: [{
                        text: {
                            text: [
                                "Nosso horário de funcionamento é de segunda a sexta-feira, das 8h às 18h.\n\n Posso te ajudar com mais alguma coisa?"
                            ]
                        }
                    }]
                });
            }

            else if (intencao === 'FormasAtendimento') {
                return res.json({
                    fulfillmentMessages: [{
                        text: {
                            text: [
                                "Nossas formas de atendimento são:\n- WhatsApp: (14) 99999-0000\n- E-mail: suporte@empresa.com.br\n- Presencial: Rua Exemplo, 123 - Centro\n\n Deseja mais alguma informação?"
                            ]
                        }
                    }]
                });
            }

            else if (intencao === 'LocalizacaoEmpresa') {
                return res.json({
                    fulfillmentMessages: [{
                        text: {
                            text: [
                                "Estamos localizados na Rua Exemplo, 123 - Centro, Osvaldo Cruz - SP.\n\nPosso ajudar em algo mais?"
                            ]
                        }
                    }]
                });
            }

            else if (intencao === 'NaoNovaPergunta') {
                return res.json({
                    fulfillmentMessages: [{
                        text: {
                            text: ["Tudo bem! Se precisar de algo, só digitar menu ou voltar"]
                        }
                    }]
                });
            }

// ------- COLETAR DADOS PARA CADASTRO--------
            else if (intencao === 'ColetarDados') {
                const frase = String(req.body.queryResult.parameters.frase || req.body.queryResult.queryText);
                console.log("Frase recebida:", frase);
                console.log("Tipo de frase:", typeof frase);

                const dataAtual = new Date();

                // regex para frase completa igual o ex do professor
                const regexCompleta = /nome\s+é\s+([\wÀ-ÿ\s]+),.*?matr[ií]cula\s+é\s+([\d\-]+),.*?moro\s+na\s+rua\s+([\wÀ-ÿ\s]+),\s*(\d+),\s*em\s+([\wÀ-ÿ\s]+)\/([A-Z]{2}).*?telefone\s+é\s+(\d{2}[-\s]?\d{4,5}[-\s]?\d{4})/i;

                // regex para frase curta: Maria 12345 Rua Z 11999999999
                const regexCurta = /^([\wÀ-ÿ\s]+)\s+([\d\-]+)\s+([\wÀ-ÿ\s]+)\s+(\d{8,15})$/i;


                let nome, matricula, endereco, telefone;

                const matchCompleta = frase.match(regexCompleta);
                const matchCurta = frase.match(regexCurta);

                if (matchCompleta) {
                    nome = matchCompleta[1].trim();
                    matricula = matchCompleta[2].trim();
                    const rua = matchCompleta[3].trim();
                    const numero = matchCompleta[4].trim();
                    const cidade = matchCompleta[5].trim();
                    const estado = matchCompleta[6].trim();
                    telefone = matchCompleta[7].replace(/\s+/g, '');
                    endereco = `Rua ${rua}, ${numero}, ${cidade} - ${estado}`;

                } else if (matchCurta) {
                    nome = matchCurta[1].trim();
                    matricula = matchCurta[2].trim();
                    endereco = matchCurta[3].trim();
                    telefone = matchCurta[4].trim();
                } else {
                    return res.json({
                        fulfillmentMessages: [{
                            text: {
                                text: ["Não consegui entender todos os dados. Por favor, envie no formato: Nome, matrícula, endereço e telefone."]
                            }
                        }]
                    });
                }

                // recuperar nome do serviço do contexto 
                const contexts = req.body.queryResult.outputContexts || [];
                let servicoTI = '';

                for (const ctx of contexts) {
                    if (ctx.name.includes('registrarproblema-followup')) {
                        servicoTI = ctx.parameters['servico-ti'] || '';
                        break;
                    }
                }

                try {
                    const usuario = new Usuario(0, nome, matricula, endereco, telefone);
                    const idUsuario = await usuario.gravar();

                    const tecnico = new Tecnico();
                    const escolhido = await tecnico.sortearTecnico();

                    
                    const servico = new Servico();
                    const infoServico = await servico.consultarPorNome(servicoTI);

                    if (!infoServico) {
                        return res.json({
                            fulfillmentMessages: [{
                                text: {
                                    text: ["Serviço informado não encontrado. Por favor, tente novamente."]
                                }
                            }]
                        });
                    }

                    const chamado = new Chamado(
                        0,
                        idUsuario,
                        infoServico.id,
                        escolhido.id,
                        "Aberto",
                        dataAtual
                    );

                    const idChamado = await chamado.gravar();

                    const msg = `Chamado nº ${idChamado} registrado com sucesso!\n\n` +
                        `\nTécnico: ${escolhido.nome}\n` +
                        `\nServiço: ${infoServico.nome}\n` +
                        `\nEndereço: ${endereco}\n`+ "\nDigite Menu para voltar"
                        ;

                    res.json({
                        fulfillmentMessages: [{
                            text: { text: [msg] }
                        }]
                    });

                } catch (erro) {
                    res.json({
                        fulfillmentMessages: [{
                            text: { text: [`Erro ao registrar chamado: ${erro.message}`] }
                        }]
                    });
                }
            }

// ------- CONSULTA CHAMAO E AGUARDA O USUARIO DIGITAR O PROTOCOLO--------
            else if (intencao === 'ConsultaChamado') {
                return res.json({
                    fulfillmentMessages: [{
                        text: {
                            text: ["Por favor, informe o número do protocolo para realizar a consulta."]
                        }
                    }]
                });
            }

        // ------- RECEBE O NUMERO O PROTOCOLO --------
            else if (intencao === 'AguardandoProtocolo') {
                const protocolo = req.body.queryResult.parameters.protocolo;

                if (!protocolo || isNaN(protocolo)) {
                    return res.json({
                        fulfillmentMessages: [{
                            text: {
                                text: ["Número inválido. Por favor, informe apenas o número do protocolo."]
                            }
                        }]
                    });
                }

                try {
                    const chamado = new Chamado();
                    const info = await chamado.consultarPorId(protocolo);

                    if (info) {
                        return res.json({
                            fulfillmentMessages: [
                                {
                                    text: {
                                        text: [
                                            `Chamado nº ${info.id} localizado.`,
                                            `Status: ${info.status}`,
                                            `Técnico: ${info.tecnico}`,
                                            `Serviço: ${info.servico}`
                                        ]
                                    }
                                },
                                {
                                    text: {
                                        text: ["Deseja consultar outro protocolo? Se sim, envie o número. Se não, basta responder 'não'."]
                                    }
                                }
                            ],
                            outputContexts: [
                                {
                                    name: `${req.body.session}/contexts/aguardando_protocolo`,
                                    lifespanCount: 5
                                }
                            ]
                        });
                    } else {
                        return res.json({
                            fulfillmentMessages: [{
                                text: {
                                    text: ["Chamado não encontrado. Verifique o número informado."]
                                }
                            }]
                        });
                    }

                } catch (erro) {
                    return res.json({
                        fulfillmentMessages: [{
                            text: {
                                text: [`Erro ao consultar o chamado: ${erro.message}`]
                            }
                        }]
                    });
                }
            }
          // ------- CAPTA O PROBLEMA --------
            else if (intencao === 'RegistrarProblema') {
                const servicoNome = req.body.queryResult.parameters['servico-ti'];

                try {
                    const servico = new Servico();
                    const infoServico = await servico.consultarPorNome(servicoNome);

                    if (infoServico) {
                        res.json({
                            fulfillmentMessages: [{
                                text: {
                                    text: [
                                        `Entendido! O prazo para atendimento ao serviço "${infoServico.nome}" é de até ${infoServico.prazo}.`,
                                        "Deseja suporte a mais alguma coisa? Digite Sim ou Não"
                                    ]
                                }
                            }]
                        });
                    } else {
                        res.json({
                            fulfillmentMessages: [{
                                text: {
                                    text: ["Serviço não encontrado. Por favor, informe um serviço válido."]
                                }
                            }]
                        });
                    }

                } catch (erro) {
                    res.json({
                        fulfillmentMessages: [{
                            text: { text: [`Erro ao consultar serviço: ${erro.message}`] }
                        }]
                    });
                }
            }

            // Fallback PADRAO
            else if (intencao === 'Default Fallback Intent') {
                res.json({
                    fulfillmentMessages: [{
                        text: {
                            text: ["Desculpe, não entendi. Pode repetir de outra forma?"]
                        }
                    }]
                });
            }
        }
    }
}
